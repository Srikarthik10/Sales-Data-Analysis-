# Data dictionary

| Column | Meaning |
|---|---|
| Order_ID | Unique order-line identifier |
| Order_Date | Date of the order |
| Customer_ID | Synthetic customer identifier |
| City | City assigned to the order |
| Region | Broad sales region |
| Segment | Customer segment |
| Category | Product category |
| Product | Product name |
| Quantity | Units purchased |
| Unit_Price | Price per unit before discount |
| Discount | Discount rate as a decimal (e.g. 0.10 = 10%) |
| Sales | Quantity multiplied by unit price |
| Profit | Simulated profit amount |

All records and customer identifiers are synthetic and generated for this portfolio exercise.
