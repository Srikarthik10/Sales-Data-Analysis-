CREATE DATABASE IF NOT EXISTS sales_analysis;
USE sales_analysis;

DROP TABLE IF EXISTS sales;

CREATE TABLE sales (
    Order_ID VARCHAR(20) PRIMARY KEY,
    Order_Date DATE NOT NULL,
    Customer_ID VARCHAR(20),
    City VARCHAR(80),
    Region VARCHAR(20),
    Segment VARCHAR(30),
    Category VARCHAR(40),
    Product VARCHAR(80),
    Quantity INT,
    Unit_Price DECIMAL(10,2),
    Discount DECIMAL(5,2),
    Sales DECIMAL(12,2),
    Profit DECIMAL(12,2)
);

-- After creating the table, import data/sales_data.csv using
-- MySQL Workbench: right-click sales table > Table Data Import Wizard.
