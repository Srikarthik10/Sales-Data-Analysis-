USE sales_analysis;

-- 1. Overall KPIs
SELECT
    ROUND(SUM(Sales), 2) AS total_sales,
    ROUND(SUM(Profit), 2) AS total_profit,
    COUNT(DISTINCT Order_ID) AS total_orders,
    ROUND(SUM(Sales) / COUNT(DISTINCT Order_ID), 2) AS average_order_value,
    ROUND(SUM(Profit) / SUM(Sales) * 100, 2) AS profit_margin_pct
FROM sales;

-- 2. Sales and profit by category
SELECT Category,
       ROUND(SUM(Sales), 2) AS total_sales,
       ROUND(SUM(Profit), 2) AS total_profit
FROM sales
GROUP BY Category
ORDER BY total_sales DESC;

-- 3. Regional performance
SELECT Region,
       ROUND(SUM(Sales), 2) AS total_sales,
       ROUND(SUM(Profit), 2) AS total_profit
FROM sales
GROUP BY Region
ORDER BY total_sales DESC;

-- 4. Monthly sales trend
SELECT DATE_FORMAT(Order_Date, '%Y-%m') AS sales_month,
       ROUND(SUM(Sales), 2) AS monthly_sales,
       ROUND(SUM(Profit), 2) AS monthly_profit
FROM sales
GROUP BY DATE_FORMAT(Order_Date, '%Y-%m')
ORDER BY sales_month;

-- 5. Top 10 products by sales
SELECT Product,
       SUM(Quantity) AS units_sold,
       ROUND(SUM(Sales), 2) AS total_sales,
       ROUND(SUM(Profit), 2) AS total_profit
FROM sales
GROUP BY Product
ORDER BY total_sales DESC
LIMIT 10;

-- 6. Segment performance
SELECT Segment,
       COUNT(DISTINCT Order_ID) AS total_orders,
       ROUND(SUM(Sales), 2) AS total_sales,
       ROUND(SUM(Profit), 2) AS total_profit
FROM sales
GROUP BY Segment
ORDER BY total_sales DESC;

-- 7. Discount band vs profit
SELECT
    CASE
        WHEN Discount = 0 THEN 'No discount'
        WHEN Discount <= 0.10 THEN '1%-10%'
        WHEN Discount <= 0.15 THEN '11%-15%'
        ELSE 'Above 15%'
    END AS discount_band,
    COUNT(*) AS order_lines,
    ROUND(SUM(Sales), 2) AS total_sales,
    ROUND(SUM(Profit), 2) AS total_profit
FROM sales
GROUP BY discount_band
ORDER BY total_profit DESC;
