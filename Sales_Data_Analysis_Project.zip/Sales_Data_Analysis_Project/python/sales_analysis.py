from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA_FILE = ROOT / "data" / "sales_data.csv"
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)

df = pd.read_csv(DATA_FILE, parse_dates=["Order_Date"])

# Basic validation
required = {"Order_ID", "Order_Date", "Category", "Product", "Region", "Sales", "Profit"}
missing = required - set(df.columns)
if missing:
    raise ValueError(f"Missing required columns: {sorted(missing)}")

df = df.drop_duplicates(subset=["Order_ID"])
df = df.dropna(subset=["Order_ID", "Order_Date", "Sales", "Profit"])

total_sales = df["Sales"].sum()
total_profit = df["Profit"].sum()
total_orders = df["Order_ID"].nunique()
aov = total_sales / total_orders if total_orders else 0
margin = (total_profit / total_sales * 100) if total_sales else 0

summary = (
    f"TOTAL SALES: {total_sales:,.2f}\n"
    f"TOTAL PROFIT: {total_profit:,.2f}\n"
    f"TOTAL ORDERS: {total_orders:,}\n"
    f"AVERAGE ORDER VALUE: {aov:,.2f}\n"
    f"PROFIT MARGIN: {margin:.2f}%\n"
    f"DATA ROWS ANALYZED: {len(df):,}\n"
    "\nNote: These figures describe the synthetic learning dataset only.\n"
)
(REPORTS / "summary_metrics.txt").write_text(summary, encoding="utf-8")
print(summary)

# Monthly sales trend
monthly = df.set_index("Order_Date").resample("MS")["Sales"].sum()
plt.figure(figsize=(10, 5))
monthly.plot(marker="o")
plt.title("Monthly Sales Trend (Synthetic Dataset)")
plt.xlabel("Month")
plt.ylabel("Sales")
plt.tight_layout()
plt.savefig(REPORTS / "monthly_sales_trend.png", dpi=160)
plt.close()

# Category sales
category_sales = df.groupby("Category")["Sales"].sum().sort_values(ascending=False)
plt.figure(figsize=(8, 5))
category_sales.plot(kind="bar")
plt.title("Sales by Category (Synthetic Dataset)")
plt.xlabel("Category")
plt.ylabel("Sales")
plt.xticks(rotation=20, ha="right")
plt.tight_layout()
plt.savefig(REPORTS / "sales_by_category.png", dpi=160)
plt.close()

# Regional profit
region_profit = df.groupby("Region")["Profit"].sum().sort_values(ascending=False)
plt.figure(figsize=(8, 5))
region_profit.plot(kind="bar")
plt.title("Profit by Region (Synthetic Dataset)")
plt.xlabel("Region")
plt.ylabel("Profit")
plt.tight_layout()
plt.savefig(REPORTS / "profit_by_region.png", dpi=160)
plt.close()

print(f"Charts and metrics saved in: {REPORTS}")
